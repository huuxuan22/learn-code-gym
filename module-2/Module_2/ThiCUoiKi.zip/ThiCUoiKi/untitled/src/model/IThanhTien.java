package model;

public interface IThanhTien {
    float tinhThanhTien();
}
